/*
*    Tom Nguyen: cssc1086
*    Jayrald Nazareno: cssc1201
*    Ari Cruz: cssc1063
*    CS 570, Summer 2018
*    June 08, 2018
*    Assignment#1,  Thread Manager
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <sys/types.h>
#include <ctype.h>


sem_t FLAG;
FILE *fp;
FILE *file;


void *my_thread(void *vargp) {
    int counter = 0;
    char* cards[13] = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};



    while(counter != 13) {
        sem_wait(&FLAG);
        file = fopen("STACK.txt", "a");
        printf("Thread <%d> is running. \n", (int)vargp);
        if((int)vargp == 0) {
            fprintf(file,"Diamond %s\n",cards[counter]); // cards[counter]
        }
        if((int)vargp == 1) {
            fprintf(file,"Club %s\n",cards[counter]);
        }
        if((int)vargp == 2) {
            fprintf(file,"Heart %s\n", cards[counter]);
        }
        if((int)vargp == 3) {
            fprintf(file,"Spade %s\n", cards[counter]);
        }
        fclose(file);
        counter++;
        sem_post(&FLAG);
        if((int)vargp == 0) {
            usleep(125);//125 milliseconds
        }
        if((int)vargp == 1) {
            usleep(250);
        }
        if((int)vargp == 2) {
            usleep(500);
        }
        if((int)vargp == 3) {
            usleep(750);
        }
    }
}


int main() {
    int fp,i;
    file = fopen("STACK.txt", "w");
    fclose(file);
    sem_init(&FLAG, 0, 1);
    pthread_t tids[5];
    for(i = 0; i < 4; i++) {
        pthread_create(&tids[i], NULL, my_thread, (void *)i);
    }
    for(i = 0; i < 4; i++) {
        pthread_join(tids[i], NULL);
    }
    sem_destroy(&FLAG);
    printf("All threads are done, exiting now. \n");
}
