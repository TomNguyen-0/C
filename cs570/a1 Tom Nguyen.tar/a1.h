/*
*    Tom Nguyen: cssc1086
*    Jayrald Nazareno: cssc1201
*    Ari Cruz: cssc1063
*    CS 570, Summer 2018
*    June 08, 2018
*    Assignment#1,  Thread Manager
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h> // for open
#include <unistd.h> // for close
#include <semaphore.h>
#include <pthread.h>

int thread_manager(void);
void *stack_output(void *tid);
void *my_thread(void *vargp);

